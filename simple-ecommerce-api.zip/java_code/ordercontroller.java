package com.example.ecommerce.controller;

import com.example.ecommerce.entity.Order;
import com.example.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {
    @Autowired private OrderService svc;

    @PostMapping("/create")
    public Order create(@AuthenticationPrincipal String username){
        return svc.create(username);
    }

    @GetMapping("/history")
    public List<Order> history(@AuthenticationPrincipal String username){
        return svc.history(username);
    }
}
