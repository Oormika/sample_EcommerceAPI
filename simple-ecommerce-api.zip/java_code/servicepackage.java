package com.example.ecommerce.service;

import com.example.ecommerce.entity.*;
import com.example.ecommerce.repository.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserService {
    @Autowired private UserRepository userRepo;
    @Autowired private BCryptPasswordEncoder encoder;

    public User register(String username, String password, String role) {
        if (userRepo.findByUsername(username) != null) throw new RuntimeException("User exists");
        User u = new User();
        u.setUsername(username);
        u.setPassword(encoder.encode(password));
        u.setRole(role);
        return userRepo.save(u);
    }
}

@Service
public class ProductService {
    @Autowired private ProductRepository productRepo;

    public Page<Product> listAll(Pageable pg) {
        return productRepo.findAll(pg);
    }
    public Page<Product> search(String q, Pageable pg) {
        return productRepo.findByNameContainingIgnoreCaseOrCategoryContainingIgnoreCase(q,q,pg);
    }
    public Product add(Product p) { return productRepo.save(p); }
    public Product update(Long id, Product in) {
        Product p = productRepo.findById(id).orElseThrow();
        p.setName(in.getName()); p.setDescription(in.getDescription());
        p.setPrice(in.getPrice()); p.setCategory(in.getCategory());
        return productRepo.save(p);
    }
    public void delete(Long id) { productRepo.deleteById(id); }
}

@Service
public class CartService {
    @Autowired private CartItemRepository cartRepo;
    @Autowired private UserRepository userRepo;
    @Autowired private ProductRepository productRepo;

    public List<CartItem> list(String username) {
        User u = userRepo.findByUsername(username);
        return cartRepo.findByUser(u);
    }
    public CartItem add(String username, Long pid, int qty) {
        User u = userRepo.findByUsername(username);
        Product p = productRepo.findById(pid).orElseThrow();
        CartItem item = cartRepo.findByUserAndProduct(u,p);
        if (item!=null) { item.setQuantity(item.getQuantity()+qty); }
        else { item = new CartItem(); item.setUser(u); item.setProduct(p); item.setQuantity(qty); }
        return cartRepo.save(item);
    }
    public void update(String username, Long cid, int qty){
        CartItem item = cartRepo.findById(cid).orElseThrow();
        if (qty <= 0) cartRepo.delete(item);
        else { item.setQuantity(qty); cartRepo.save(item); }
    }
    public void remove(Long cid) { cartRepo.deleteById(cid); }
}

@Service
public class OrderService {
    @Autowired private CartItemRepository cartRepo;
    @Autowired private OrderRepository orderRepo;
    @Autowired private UserRepository userRepo;

    public Order create(String username) {
        User u = userRepo.findByUsername(username);
        List<CartItem> items = cartRepo.findByUser(u);
        if (items.isEmpty()) throw new RuntimeException("Cart empty");

        Order o = new Order();
        o.setUser(u);

        double total = 0;
        for (CartItem ci : items) {
            OrderItem oi = new OrderItem();
            oi.setProduct(ci.getProduct());
            oi.setQuantity(ci.getQuantity());
            oi.setPrice(ci.getProduct().getPrice());
            o.getItems().add(oi);
            total += ci.getQuantity() * ci.getProduct().getPrice();
        }
        o.setTotal(total);
        cartRepo.deleteAll(items);
        return orderRepo.save(o);
    }

    public List<Order> history(String username) {
        User u = userRepo.findByUsername(username);
        return orderRepo.findByUser(u);
    }
}
