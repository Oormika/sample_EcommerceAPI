package com.example.ecommerce.dto;

public class AuthRequest {
    private String username, password, role;
    // getters/setters…
}

public class AuthResponse {
    private String token;
    public AuthResponse(String token){ this.token = token; }
    // getter…
}

public class CartRequest {
    private Long productId, cartItemId;
    private int quantity;
    // getters/setters…
}
