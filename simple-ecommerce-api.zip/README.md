
# Simple E-commerce API (Java + Spring Boot)

This is a fully functional Java-based E-commerce API using Spring Boot, Spring Security, and JWT.

## Features
- User Registration/Login with JWT authentication
- Role-based access (Customer/Admin)
- Product Listing, Search, and Pagination
- Cart Management (add, update, remove items)
- Order Creation from Cart
- Admin Product Management
- Basic Frontend Support (optional via Thymeleaf)

## How to Run
1. Clone the repo or extract ZIP.
2. Run `mvn spring-boot:run`.
3. Access H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:testdb`)

## License
MIT
